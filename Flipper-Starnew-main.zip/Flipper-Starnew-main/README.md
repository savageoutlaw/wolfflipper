# Flipper-Starnew

Universal Intercom keys by StarNew - https://starnew.ru/
+ New undefined dumps

StarButton - to ibutton folder,
StarRFID - to lfrfid folder

Dumped by Russian Elevator - https://www.youtube.com/@iah_lift , say thanks to him in the comments

--------------------------------------------------------------------------------------------------

Универсальные ключи StarNew в формате для Flipper Zero
+ Новые дампы 

StarButton - В папку ibutton,
StarRFID - В папку lfrfid

Изначальные дампы сделал Russian Elevator - https://www.youtube.com/@iah_lift , за что огромнейшее ему спасибо
