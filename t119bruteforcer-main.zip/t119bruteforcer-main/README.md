# t119bruteforcer
Retekess pager system t119 bruteforcer for the flipper zero 

updated bruteforcer is t119bruteforcerupdated.sub, prefer this one
the other sub files are from the old research, they still work but are partially correct

special thanks to @ShotokanZH for the amazing work!

https://twitter.com/xenobyte_/status/1554222170888339456
https://twitter.com/xenobyte_/status/1558123251276070912
