This is a [massive collection](https://github.com/probonopd/irdb) of CSV formatted IR codes that have now been converted to the Flipper IR format.

Thank you Code6 for the conversion and files! [Converter by Spexivus](https://github.com/Spexivus/csv2ir).

**PLEASE NOTE:** These files are untested and MAY be in a different protocol than what the Flipper is expecting. This could cause them to be incompatible and not work. If you're looking for something that isn't present elsewhere, it's still a good thing to try. Please let us know if you find one that doesn't work!
