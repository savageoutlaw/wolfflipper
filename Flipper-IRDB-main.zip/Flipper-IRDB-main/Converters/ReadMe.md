Digital and/or analog converters
