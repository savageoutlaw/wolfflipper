# Flipper_Zero_Badusb_hack5_payloads
hack5 badusb payloads moded for be played with flipper zero
