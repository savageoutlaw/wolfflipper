# Useful scripts

Полезные скрипты

<pre>
Array
(
    [FlipperFileFormat] => <a href="//github.com/wetox-team/flipperzero-goodies/tree/master/scripts/fff">./fff</a>,
    [key-utils] => <a href="//github.com/wetox-team/flipperzero-goodies/tree/master/scripts/key-utils">./key-utils</a>
)
</pre>

---

__from wetox with love__
