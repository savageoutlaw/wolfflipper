# Starnew universal intercom keys from <a target="_blank" href="https://github.com/GlUTEN-BASH/Flipper-Starnew">StarNew</a>

Универсальные ключи для домофонов от <a target="_blank" href="https://github.com/GlUTEN-BASH/Flipper-Starnew">StarNew</a>

<pre>
Array
(
    [ibutton] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/starnew/keys/ibutton">./keys/ibutton</a>,
    [lfrfid] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/starnew/keys/lfrfid">./keys/lfrfid</a>,
    [nfc] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/starnew/keys/nfc">./keys/nfc</a>
)
</pre>

---

__from wetox with love__
