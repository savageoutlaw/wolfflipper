# Universal intercom keys

Универсальные ключи от домофонов

<pre>
Array
(
    [spb] => <a href="./spb">./spb</a>,
    [msk] => <a href="./msk">./msk</a>,
    [brn] => <a href="./brn">./brn</a>,
    [kgn] => <a href="./kgn">./kgn</a>,
    [starnew] => <a href="./starnew">./starnew</a>,
    [unknwn] => <a href="./unknwn">./unknwn</a>,
)
</pre>

p.s. if you have universal intercom keys, but you can't scan it, then get into contact with me: sunny.capt@tuta.io | https://t.me/lambda_function or just open a pull request

p.p.s. keys for one city may work in another

---

__from wetox with love__
