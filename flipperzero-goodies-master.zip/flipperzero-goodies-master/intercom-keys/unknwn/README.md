# Unknown universal intercom keys

Неизвестные универсальные ключи от домофонов 

<pre>
Array
(
    [ibutton] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/unknwn/keys/ibutton">./keys/ibutton</a>,
    [lfrfid] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/unknwn/keys/lfrfid">./keys/lfrfid</a>,
    [nfc] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/unknwn/keys/nfc">./keys/nfc</a>
)
</pre>

---

__from wetox with love__
