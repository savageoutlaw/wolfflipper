# Universal intercom keys for Barnaul

Универсальные ключи от домофонов Барнаула

<pre>
Array
(
    [ibutton] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/brn/keys/ibutton">./keys/ibutton</a>,
    [lfrfid] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/brn/keys/lfrfid">./keys/lfrfid</a>,
    [nfc] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/brn/keys/nfc">./keys/nfc</a>
)
</pre>

---

__from wetox with love__
