# Universal intercom keys for Kurgan

Универсальные ключи от домофонов Кургана

<pre>
Array
(
    [ibutton] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/kgn/keys/ibutton">./keys/ibutton</a>,
    [lfrfid] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/kgn/keys/lfrfid">./keys/lfrfid</a>,
    [nfc] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/kgn/keys/nfc">./keys/nfc</a>
)
</pre>

---

__from wetox with love__
