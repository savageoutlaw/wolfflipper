# Universal intercom keys for St. Petersburg

Универсальные ключи от домофонов Питера

<pre>
Array
(
    [ibutton] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/spb/keys/ibutton">./keys/ibutton</a>,
    [lfrfid] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/spb/keys/lfrfid">./keys/lfrfid</a>,
    [nfc] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/spb/keys/nfc">./keys/nfc</a>,
    [lfrfid-by-proxmark3] => <a target="_blank" href="//github.com/wetox-team/flipperzero-goodies/tree/master/intercom-keys/spb/dumped-by-proxmark3">./keys/dumped-by-proxmark3</a>,
)
</pre>

---

__from wetox with love__
