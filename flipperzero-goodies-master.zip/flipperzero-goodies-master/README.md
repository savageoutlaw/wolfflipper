# Some usefull data for flipper zero

<pre>
Array
(
    [intercom-keys] => <a href="./intercom-keys">./intercom-keys</a>,
    [scripts] => <a href="./scripts">./scripts</a>
)
</pre>

---

__from wetox with love__
